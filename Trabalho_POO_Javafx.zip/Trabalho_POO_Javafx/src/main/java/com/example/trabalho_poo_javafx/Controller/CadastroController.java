package com.example.trabalho_poo_javafx.Controller;

//STATUS DO CONTROLADOR: WORKING
//IMPORTES DO CONTROLADOR
import com.example.trabalho_poo_javafx.App;
import com.example.trabalho_poo_javafx.Model.Cadastro;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;

import javafx.collections.FXCollections;
import javafx.scene.control.ComboBox;


public class CadastroController {

        @FXML
        private ComboBox<String> cb_Planos;

        @FXML
        private AnchorPane pn_Principal;

        @FXML
        private TextField txt_Nome;

        @FXML
        private TextField txt_Cpf;

        @FXML
        private TextField txt_Num_Cartao;

        @FXML
        private TextField txt_Email;

        @FXML
        private TextField txt_Senha;

        @FXML
        private TextField txt_Idade;

        @FXML
        private Label lbl_TextoCadastro;

        @FXML
        private Label lbl_Nome;

        @FXML
        private Label lbl_Cpf;

        @FXML
        private Label lbl_Num_Cartao;

        @FXML
        private Label lbl_Idade;

        @FXML
        private Label lbl_Senha;

        @FXML
        private Label lbl_Email;

        @FXML
        private Button btn_Salvar;




        //ESTRUTURAR CLASSE CADASTRO PARA CRIAR OBJETO
        //CASO OCARRA PROBLEMA TESTAR STATIC
        public void Salvarbtn(ActionEvent event)
        {
            if(event.getSource() == btn_Salvar)
            {

                    Cadastro cadastro = new Cadastro();
                    cadastro.setNome(txt_Nome.getText());
                    //SET CPF
                    Boolean check = cadastro.validarCpf(txt_Cpf.getText());
                    if (check)
                    {
                            cadastro.setCpf(txt_Cpf.getText());
                    }
                    else
                    {
                            Alert alert = new Alert(Alert.AlertType.INFORMATION);
                            alert.setTitle("Alerta!!!");
                            alert.setHeaderText(null);
                            alert.setContentText("Erro: CPF Inválido");
                            alert.showAndWait();
                    }
                    //SET CPF
                    //SET IDADE
                    try
                    {
                            int idade = Integer.parseInt(txt_Idade.getText());
                            cadastro.setIdade(idade);
                    }
                    catch (NumberFormatException e) {
                            Alert alert = new Alert(Alert.AlertType.INFORMATION);
                            alert.setTitle("Alerta!!!");
                            alert.setHeaderText(null);
                            alert.setContentText("Erro: Idade Inválido");
                            alert.showAndWait();
                    }
                    //SET IDADE
                    cadastro.setNum_cartao(txt_Num_Cartao.getText());
                    cadastro.setLogin(txt_Email.getText());
                    cadastro.setSenha(txt_Senha.getText());







                    //VERIFICANDO ITENS
                    System.out.println(cadastro.getNome());
                    System.out.println(cadastro.getCpf());
                    System.out.println(cadastro.getIdade());
                    System.out.println(cadastro.getNum_cartao());
                    System.out.println(cadastro.getLogin());
                    System.out.println(cadastro.getSenha());
                    App.TrocarTela("login");


            }



        }








        //INICIALIZANDO COMBO BOX
        public void initialize()
        {
                //SETANDO VALORES PARA A COMBO BOX
                ObservableList<String> opcoesPlano = FXCollections.observableArrayList("Plano Simples", "Plano Premium");
                cb_Planos.setItems(opcoesPlano);


                //NESTE TRECHO OCORRE A CAPTURA DO ELEMENTO DO QUE FOI SELECIONADO NA COMBO BOX
                cb_Planos.setOnAction(event ->
                {
                        String planoSelecionado = cb_Planos.getSelectionModel().getSelectedItem();
                        System.out.println("Plano selecionado: " + planoSelecionado);
                });


        }







    }






