package com.example.trabalho_poo_javafx.Controller;

import com.example.trabalho_poo_javafx.App;
import com.example.trabalho_poo_javafx.Model.Filme;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


public class HomeController {

    @FXML
    private TextField txt_Busca;

    @FXML
    private ListView<Filme> lv_Filmes;

    private List<Filme> filmeList = new ArrayList<>();

    private ObservableList<Filme> filmeObservableList;

    @FXML
    private Label lbl_ClienteNome;

    @FXML
    private Label lbl_Plano;

    @FXML
    private Button btn_Sair;

    @FXML
    private Button btn_buscar;

    @FXML
    private Pane pn_Cliente;


    public void initialize()
    {
        //TESTE DE ADIÇÃO
        Filme filme1 = new Filme("Superman O Retorno", 1998, 2);
        Filme filme2 = new Filme("Batman Cavaleiro das Trevas", 2013, 1.30);

        //ADIÇÃO DE FILMES A LISTA
        filmeList.add(filme1);
        filmeList.add(filme2);
        filmeList.add(new Filme("Harry Potter e a Pedra Filosofal", 2001, 2.32));
        filmeList.add(new Filme("O Senhor dos Anéis: A Sociedade do Anel", 2001, 2.58));
        filmeList.add(new Filme("Titanic", 1997, 3.14));
        filmeList.add(new Filme("Avatar", 2009, 2.42));
        filmeList.add(new Filme("Jurassic Park", 1993, 2.07));
        filmeList.add(new Filme("Vingadores: Ultimato", 2019, 3.01));
        filmeList.add(new Filme("Matrix", 1999, 2.16));
        filmeList.add(new Filme("Star Wars: Episódio IV - Uma Nova Esperança", 1977, 2.01));
        filmeList.add(new Filme("Os Incríveis", 2004, 1.55));
        filmeList.add(new Filme("O Poderoso Chefão", 1972, 2.55));
        filmeList.add(new Filme("Interestelar", 2014, 2.49));
        filmeList.add(new Filme("Indiana Jones: Os Caçadores da Arca Perdida", 1981, 1.55));
        filmeList.add(new Filme("E.T. - O Extraterrestre", 1982, 1.55));
        filmeList.add(new Filme("O Rei Leão", 1994, 1.29));
        filmeList.add(new Filme("De Volta para o Futuro", 1985, 1.56));
        filmeList.add(new Filme("Pulp Fiction: Tempo de Violência", 1994, 2.34));
        filmeList.add(new Filme("Gladiador", 2000, 2.35));
        filmeList.add(new Filme("Toy Story", 1995, 1.21));
        filmeList.add(new Filme("Forrest Gump: O Contador de Histórias", 1994, 2.22));
        filmeList.add(new Filme("Cidade de Deus", 2002, 2.10));
        filmeList.add(new Filme("O Silêncio dos Inocentes", 1991, 1.58));
        filmeList.add(new Filme("Clube da Luta", 1999, 2.19));
        filmeList.add(new Filme("O Exterminador do Futuro 2: O Julgamento Final", 1991, 2.17));
        filmeList.add(new Filme("O Labirinto do Fauno", 2006, 1.59));
        filmeList.add(new Filme("A Origem", 2010, 2.28));
        filmeList.add(new Filme("Batman Begins", 2005, 2.20));
        filmeList.add(new Filme("A Viagem de Chihiro", 2001, 2.05));
        filmeList.add(new Filme("Os Sete Samurais", 1954, 3.27));

        filmeObservableList = FXCollections.observableArrayList(filmeList);

        lv_Filmes.setItems(filmeObservableList);


        btn_buscar.setOnAction(event -> {
            String Term_busca = txt_Busca.getText().trim().toLowerCase();
            if (!Term_busca.isEmpty()) {
                List<Filme> filteredList = filmeObservableList.stream()
                        .filter(filme -> filme.getNome().toLowerCase().contains(Term_busca))
                        .collect(Collectors.toList());
                lv_Filmes.setItems(FXCollections.observableArrayList(filteredList));
            } else {
                lv_Filmes.setItems(filmeObservableList);
            }
        });



    }

    public void Btn_Sair(ActionEvent event)
    {
        App.TrocarTela("login");

    }








}


