package com.example.trabalho_poo_javafx.Controller;

import com.example.trabalho_poo_javafx.App;
import com.example.trabalho_poo_javafx.Model.Cadastro;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.control.PasswordField;
import com.example.trabalho_poo_javafx.Controller.CadastroController.*;

import java.util.regex.Pattern;

public class LoginController {

    @FXML
    private VBox Pag;

    @FXML
    private AnchorPane pn_PainelPrincipal;

    @FXML
    private MenuBar br_Menu;

    @FXML
    private TextField txt_Email;

    @FXML
    private Label lbl_TituloPagina;

    @FXML
    private Label lbl_email;

    @FXML
    private Label lbl_Senha;

    @FXML
    private Button btn_Login;

    @FXML
    private PasswordField txt_Senha;

    @FXML
    private Hyperlink link_Cadastro;





    // APLICAR CLASSE CADASTRO
    public void Acao_btn(ActionEvent event)
    {
        if (event.getSource() == btn_Login )
        {

            System.out.println("teste");



            String email_pattern = ("[a-zA-Z0-9]+@[a-zA-Z0-9]+\\.[a-zA-Z0-9]+");
            String email = txt_Email.getText().trim();
            String senha = txt_Senha.getText();


            if(Pattern.matches(email_pattern, email) && email.equals("admin@gmail.com") && senha.equals("admin"))
            {
                App.TrocarTela("home");
            }
            else
            {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("ERRO!");
                alert.setHeaderText(null);
                alert.setContentText("senha ou e-mail incorreto");
                alert.showAndWait();




            }


        }


    }

    public void CadastroLink(ActionEvent event)
    {
        if (event.getSource() == link_Cadastro)
        {
            App.TrocarTela("cadastro");

        }





    }













}
