package com.example.trabalho_poo_javafx.Model;

import java.util.Objects;

public class Filme
{
    private String nome;
    private int ano;
    private double duracao;

    public Filme() {
    }

    public Filme(String nome, int ano, double duracao) {
        this.nome = nome;
        this.ano = ano;
        this.duracao = duracao;
    }

    public String getNome() {
        return nome;
    }

    public int getAno() {
        return ano;
    }

    public double getDuracao() {
        return duracao;
    }

    @Override
    public String toString() {
        return nome + " (" + ano + ") - Duração: " + duracao + "h";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Filme other = (Filme) obj;
        return Objects.equals(nome, other.nome) && ano == other.ano && duracao == other.duracao;
    }

    @Override
    public int hashCode() {
        return Objects.hash(nome, ano, duracao);
    }









}
