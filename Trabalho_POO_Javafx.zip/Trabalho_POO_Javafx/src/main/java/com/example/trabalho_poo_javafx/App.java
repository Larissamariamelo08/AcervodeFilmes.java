package com.example.trabalho_poo_javafx;



import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

public class App extends Application {

    //O METODO START NÃO ACEITA VARIÁVEIS DE CLASSE DENTRO DELE
    private static Stage etapa;

    private static Scene loginScene;

    private static Scene cadastroScene;

    private static Scene homeScene;



    @Override
    public void start(Stage stage) throws IOException {

         etapa = stage;

        Parent fxmlcadastro = FXMLLoader.load(getClass().getResource("CadastroView.fxml"));
        cadastroScene = new Scene(fxmlcadastro, 640, 400);

        Parent fxmlhome = FXMLLoader.load(getClass().getResource("HomeView.fxml"));
        homeScene = new Scene(fxmlhome, 640, 400);

        Parent fxmllogin = FXMLLoader.load(getClass().getResource("LoginView.fxml"));
        loginScene = new Scene(fxmllogin, 640, 400);


        etapa.setTitle("AcervoFlix");
        etapa.setScene(loginScene);
        etapa.show();

    }

    public static void TrocarTela(String tela)
    {
        switch (tela)
        {
            case "cadastro":
                etapa.setScene(cadastroScene);
                break;

            case "login":
                etapa.setScene(loginScene);
                break;


            case "home":
                etapa.setScene(homeScene);
                break;

        }





    }





    public static void main(String[] args) {

        launch();
    }
}