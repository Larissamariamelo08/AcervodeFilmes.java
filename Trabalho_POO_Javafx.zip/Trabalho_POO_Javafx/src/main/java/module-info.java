module com.example.trabalho_poo_javafx {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.trabalho_poo_javafx to javafx.fxml;
    exports com.example.trabalho_poo_javafx;
    exports com.example.trabalho_poo_javafx.Controller;
    opens com.example.trabalho_poo_javafx.Controller to javafx.fxml;
}